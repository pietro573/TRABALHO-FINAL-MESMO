require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function autenticar(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ erro: "Faça login para continuar." });
  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ erro: "Sessão inválida. Entre novamente." });
  }
}

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/produtos", async (req, res) => {
  try {
    const { busca = "", categoria = "", ordem = "" } = req.query;
    let sql = "SELECT id, nome, descricao, categoria, preco, imagem, estoque FROM produto WHERE ativo = 1";
    const params = [];
    if (busca.trim()) {
      sql += " AND (nome LIKE ? OR descricao LIKE ?)";
      params.push(`%${busca.trim()}%`, `%${busca.trim()}%`);
    }
    if (categoria && categoria !== "Todas") {
      sql += " AND categoria = ?";
      params.push(categoria);
    }
    if (ordem === "menor") sql += " ORDER BY preco ASC";
    else if (ordem === "maior") sql += " ORDER BY preco DESC";
    else if (ordem === "nome") sql += " ORDER BY nome ASC";
    else sql += " ORDER BY id DESC";
    const [produtos] = await db.query(sql, params);
    res.json(produtos);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: "Não foi possível carregar os produtos." });
  }
});

app.get("/api/produtos/:id", async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT id, nome, descricao, categoria, preco, imagem, estoque FROM produto WHERE id = ? AND ativo = 1",
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: "Produto não encontrado." });
    res.json(rows[0]);
  } catch {
    res.status(500).json({ erro: "Erro ao buscar produto." });
  }
});

app.post("/api/clientes", async (req, res) => {
  try {
    const { nome, email, senha, cpf, celular } = req.body;
    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: "Nome, e-mail e senha são obrigatórios." });
    }
    if (senha.length < 6) return res.status(400).json({ erro: "A senha deve ter pelo menos 6 caracteres." });
    const hash = await bcrypt.hash(senha, 10);
    const [result] = await db.query(
      "INSERT INTO cliente (nome, email, senha, cpf, celular) VALUES (?, ?, ?, ?, ?)",
      [nome.trim(), email.trim().toLowerCase(), hash, cpf || null, celular || null]
    );
    res.status(201).json({ mensagem: "Cadastro realizado com sucesso!", id: result.insertId });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ erro: "Este e-mail ou CPF já está cadastrado." });
    console.error(err);
    res.status(500).json({ erro: "Não foi possível realizar o cadastro." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, senha } = req.body;
    const [rows] = await db.query("SELECT id, nome, email, senha FROM cliente WHERE email = ?", [(email || "").toLowerCase()]);
    if (!rows.length || !(await bcrypt.compare(senha || "", rows[0].senha))) {
      return res.status(401).json({ erro: "E-mail ou senha incorretos." });
    }
    const usuario = rows[0];
    const token = jwt.sign({ id: usuario.id, email: usuario.email }, process.env.JWT_SECRET, { expiresIn: "4h" });
    res.json({ token, usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: "Erro ao realizar login." });
  }
});

app.post("/api/pedidos", autenticar, async (req, res) => {
  const { itens, total } = req.body;
  if (!Array.isArray(itens) || !itens.length) return res.status(400).json({ erro: "O carrinho está vazio." });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [pedido] = await conn.query(
      "INSERT INTO pedido (cliente_id, total, status) VALUES (?, ?, 'recebido')",
      [req.usuario.id, Number(total) || 0]
    );
    for (const item of itens) {
      const [produtos] = await conn.query("SELECT preco, estoque FROM produto WHERE id = ? AND ativo = 1 FOR UPDATE", [item.id]);
      if (!produtos.length || produtos[0].estoque < item.quantidade) throw new Error("Estoque insuficiente para um dos produtos.");
      await conn.query(
        "INSERT INTO pedido_item (pedido_id, produto_id, quantidade, preco_unitario) VALUES (?, ?, ?, ?)",
        [pedido.insertId, item.id, item.quantidade, produtos[0].preco]
      );
      await conn.query("UPDATE produto SET estoque = estoque - ? WHERE id = ?", [item.quantidade, item.id]);
    }
    await conn.commit();
    res.status(201).json({ mensagem: "Pedido registrado!", pedidoId: pedido.insertId });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ erro: err.message || "Não foi possível registrar o pedido." });
  } finally {
    conn.release();
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Loja rodando em http://localhost:${PORT}`));
