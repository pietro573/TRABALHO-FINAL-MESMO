CREATE DATABASE IF NOT EXISTS loja_urbana CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE loja_urbana;

CREATE TABLE IF NOT EXISTS cliente (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) UNIQUE,
  celular VARCHAR(20),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS produto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  descricao TEXT,
  categoria VARCHAR(80) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  imagem VARCHAR(500),
  estoque INT NOT NULL DEFAULT 0,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pedido (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'recebido',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cliente_id) REFERENCES cliente(id)
);

CREATE TABLE IF NOT EXISTS pedido_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  produto_id INT NOT NULL,
  quantidade INT NOT NULL,
  preco_unitario DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (pedido_id) REFERENCES pedido(id),
  FOREIGN KEY (produto_id) REFERENCES produto(id)
);

INSERT INTO produto (nome, descricao, categoria, preco, imagem, estoque) VALUES
('Fone Pulse Pro','Som imersivo e conforto para acompanhar seu dia.','Tecnologia',189.90,'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=700',20),
('Relógio Minimal','Design elegante para todos os momentos.','Acessórios',249.90,'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700',15),
('Mochila Urban','Espaço e praticidade para a rotina.','Acessórios',159.90,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700',18),
('Câmera Instantânea','Guarde momentos especiais de um jeito único.','Tecnologia',329.90,'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=700',8),
('Tênis Street','Conforto e estilo para acompanhar seu ritmo.','Moda',219.90,'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700',12),
('Óculos Solar','Um toque de personalidade para o visual.','Moda',119.90,'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=700',25),
('Garrafa Térmica','Sua bebida na temperatura ideal por mais tempo.','Casa',79.90,'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=700',30),
('Luminária Studio','Iluminação aconchegante para seu espaço.','Casa',139.90,'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700',10);
