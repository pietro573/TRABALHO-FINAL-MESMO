const demoProducts = [
  {id:1,nome:"Fone Pulse Pro",descricao:"Som imersivo e conforto para acompanhar seu dia.",categoria:"Tecnologia",preco:189.90,imagem:"https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=700"},
  {id:2,nome:"Relógio Minimal",descricao:"Design elegante para todos os momentos.",categoria:"Acessórios",preco:249.90,imagem:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700"},
  {id:3,nome:"Mochila Urban",descricao:"Espaço e praticidade para a rotina.",categoria:"Acessórios",preco:159.90,imagem:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700"},
  {id:4,nome:"Câmera Instantânea",descricao:"Guarde momentos especiais de um jeito único.",categoria:"Tecnologia",preco:329.90,imagem:"https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=700"},
  {id:5,nome:"Tênis Street",descricao:"Conforto e estilo para acompanhar seu ritmo.",categoria:"Moda",preco:219.90,imagem:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700"},
  {id:6,nome:"Óculos Solar",descricao:"Um toque de personalidade para o visual.",categoria:"Moda",preco:119.90,imagem:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=700"},
  {id:7,nome:"Garrafa Térmica",descricao:"Sua bebida na temperatura ideal por mais tempo.",categoria:"Casa",preco:79.90,imagem:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=700"},
  {id:8,nome:"Luminária Studio",descricao:"Iluminação aconchegante para seu espaço.",categoria:"Casa",preco:139.90,imagem:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700"}
];
const $ = (s) => document.querySelector(s);
const money = (v) => Number(v).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
let products = [], cart = JSON.parse(localStorage.getItem("urbana-cart") || "[]");
let token = localStorage.getItem("urbana-token") || "";
let authMode = "login";
let toastTimer;

function notify(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2400)}
function saveCart(){localStorage.setItem("urbana-cart",JSON.stringify(cart));renderCart()}
function productImage(url,name){return `<img src="${url}" alt="${name}" loading="lazy" onerror="this.style.display='none';this.parentElement.insertAdjacentHTML('beforeend','<span class=\\'fallback\\'>✳</span>')">`}

async function loadProducts(){
  try{
    const response=await fetch("/api/produtos");
    if(!response.ok) throw new Error("API indisponível");
    products=await response.json();
    if(!products.length) products=demoProducts;
  }catch{products=demoProducts}
  const cats=[...new Set(products.map(p=>p.categoria).filter(Boolean))].sort();
  $("#categoryFilter").innerHTML='<option value="Todas">Todas as categorias</option>'+cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("");
  renderProducts();
}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderProducts(){
  const term=$("#searchInput").value.toLowerCase().trim(), cat=$("#categoryFilter").value, order=$("#sortFilter").value;
  let list=products.filter(p=>(p.nome+" "+(p.descricao||"")).toLowerCase().includes(term)&&(cat==="Todas"||p.categoria===cat));
  if(order==="menor")list.sort((a,b)=>a.preco-b.preco);if(order==="maior")list.sort((a,b)=>b.preco-a.preco);if(order==="nome")list.sort((a,b)=>a.nome.localeCompare(b.nome));
  $("#resultCount").textContent=`${list.length} ${list.length===1?"produto encontrado":"produtos encontrados"}`;
  $("#emptyState").classList.toggle("hidden",list.length!==0);
  $("#productGrid").innerHTML=list.map(p=>`<article class="product-card"><div class="product-image">${productImage(p.imagem,p.nome)}<span class="product-tag">${escapeHtml(p.categoria||"Destaque")}</span></div><div class="product-info"><span class="product-category">${escapeHtml(p.categoria||"LOJA URBANA")}</span><h3>${escapeHtml(p.nome)}</h3><p>${escapeHtml(p.descricao||"Uma ótima escolha para o seu dia.")}</p><div class="product-bottom"><strong class="price">${money(p.preco)}</strong><button class="add-button" data-add="${p.id}">Adicionar +</button></div></div></article>`).join("");
}
function addToCart(id){const p=products.find(x=>String(x.id)===String(id));if(!p)return;const item=cart.find(x=>String(x.id)===String(id));if(item)item.quantidade++;else cart.push({id:p.id,nome:p.nome,preco:Number(p.preco),imagem:p.imagem,quantidade:1});saveCart();notify("Produto adicionado à sacola!")}
function changeQuantity(id,delta){const item=cart.find(x=>String(x.id)===String(id));if(!item)return;item.quantidade+=delta;if(item.quantidade<=0)cart=cart.filter(x=>String(x.id)!==String(id));saveCart()}
function renderCart(){
 const count=cart.reduce((s,p)=>s+p.quantidade,0),total=cart.reduce((s,p)=>s+p.preco*p.quantidade,0);
 $("#cartCount").textContent=count;$("#drawerCount").textContent=`(${count})`;$("#cartTotal").textContent=money(total);
 $("#cartItems").innerHTML=cart.length?cart.map(p=>`<div class="cart-row"><img class="cart-thumb" src="${p.imagem}" alt=""><div><b>${escapeHtml(p.nome)}</b><small>${money(p.preco)} cada</small><div class="quantity"><button data-qty="${p.id}" data-delta="-1">−</button><span>${p.quantidade}</span><button data-qty="${p.id}" data-delta="1">+</button></div></div><b>${money(p.preco*p.quantidade)}</b></div>`).join(""):'<p class="empty">Sua sacola está vazia.</p>';
}
function openCart(open){$("#cartDrawer").classList.toggle("open",open);$("#cartOverlay").classList.toggle("hidden",!open)}
function openAuth(){authMode="login";updateAuthMode();$("#authModal").classList.remove("hidden")}
function updateAuthMode(){const signup=authMode==="signup";$("#authTitle").textContent=signup?"Crie sua conta":"Entre na sua conta";$("#nameField").classList.toggle("hidden",!signup);$("#nameField input").required=signup;$("#authSubmit").innerHTML=(signup?"Criar conta":"Entrar")+' <span>↗</span>';$("#switchAuth").innerHTML=signup?'Já tem uma conta? <button type="button">Entrar</button>':'Ainda não tem conta? <button type="button">Cadastre-se</button>';$("#authMessage").textContent=""}

document.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]");if(add)addToCart(add.dataset.add);
 const qty=e.target.closest("[data-qty]");if(qty)changeQuantity(qty.dataset.qty,Number(qty.dataset.delta));
});
$("#searchInput").addEventListener("input",renderProducts);$("#categoryFilter").addEventListener("change",renderProducts);$("#sortFilter").addEventListener("change",renderProducts);
$("#cartOpen").onclick=()=>openCart(true);$("#cartClose").onclick=()=>openCart(false);$("#cartOverlay").onclick=()=>openCart(false);
$("#loginOpen").onclick=openAuth;$("#authClose").onclick=()=>$("#authModal").classList.add("hidden");
$("#switchAuth").addEventListener("click",()=>{authMode=authMode==="login"?"signup":"login";updateAuthMode()});
$("#authForm").addEventListener("submit",async e=>{
 e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());const endpoint=authMode==="signup"?"/api/clientes":"/api/login";
 try{const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw new Error(result.erro||"Não foi possível continuar.");
 if(authMode==="signup"){notify("Cadastro realizado! Agora entre na sua conta.");authMode="login";updateAuthMode();e.currentTarget.reset();return}
 token=result.token;localStorage.setItem("urbana-token",token);$("#authModal").classList.add("hidden");$("#loginOpen").textContent=result.usuario.nome.split(" ")[0];notify("Login realizado com sucesso!");
 }catch(err){$("#authMessage").textContent=err.message}
});
$("#checkoutButton").onclick=async()=>{
 if(!cart.length)return notify("Adicione produtos à sacola primeiro.");
 if(!token){openCart(false);openAuth();return}
 try{const r=await fetch("/api/pedidos",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify({itens:cart.map(p=>({id:p.id,quantidade:p.quantidade})),total:cart.reduce((s,p)=>s+p.preco*p.quantidade,0)})});const data=await r.json();if(!r.ok)throw new Error(data.erro||"Erro ao finalizar pedido.");cart=[];saveCart();openCart(false);notify(`Pedido #${data.pedidoId} registrado!`);loadProducts()}catch(err){notify(err.message)}
};
renderCart();loadProducts();
