# Loja Urbana — E-commerce escolar

Projeto demonstrativo de loja virtual com interface responsiva, busca, filtros, carrinho, cadastro/login e API Node.js + MySQL.

## Requisitos
- Node.js 18 ou superior
- MySQL 8 (ou compatível)

## Como executar
1. Extraia o ZIP e abra a pasta no VS Code.
2. No MySQL Workbench/phpMyAdmin, execute todo o arquivo `database.sql`.
3. No terminal, instale as dependências:
   ```bash
   npm install
   ```
4. Copie `.env.example` para `.env` e preencha os dados do seu MySQL.
5. Inicie:
   ```bash
   npm start
   ```
6. Abra `http://localhost:3000`.

## Funcionalidades
- Catálogo de produtos com imagens.
- Pesquisa por nome/descrição.
- Filtro por categoria e ordenação por preço/nome.
- Carrinho salvo no navegador, com alteração de quantidades.
- Cadastro com senha criptografada (bcrypt) e login com token JWT.
- Registro de pedidos para usuário autenticado e baixa de estoque.
- Layout adaptado para celular e computador.

## Observações
- Se a API ou o banco não estiverem conectados, a vitrine usa produtos demonstrativos no navegador; cadastro, login e pedidos exigem MySQL funcionando.
- O checkout registra um pedido demonstrativo. Não existe integração com gateway de pagamento.
- Altere `JWT_SECRET` no `.env` antes de usar fora do ambiente local.
- As imagens de demonstração são carregadas de URLs externas; é possível trocar os links no banco ou em `public/app.js`.
